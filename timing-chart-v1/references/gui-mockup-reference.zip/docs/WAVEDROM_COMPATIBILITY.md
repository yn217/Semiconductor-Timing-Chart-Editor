# WaveDrom Compatibility and Differential Specification

## 1. Rendering principle

WaveDromの信号描画がGolden Reference。
独自Rendererで「近い形」を作ることを初期実装の目的にしない。
特にtransition斜線、bus transition、clock edge、X/Z等のgeometry差を避ける。

Preferred architecture:

Semantic Timing Model -> WaveDrom Adapter -> WaveDrom Renderer -> SVG -> Overlay Renderer

自前Rendererへ移行する場合はWaveDrom SVGとのgeometry regression testを必須とする。

## 2. WaveDrom-derived features to implement

| Feature | Implement | New editor UX |
|---|---:|---|
| 0 / 1 | Yes | value buttons / Event Table |
| X / Z | Yes | value buttons |
| weak high / weak low | Yes | signal value selection |
| state continuation (`.`) | Yes | implicit; user never types dots |
| data / bus waveform | Yes | start + value |
| data text | Yes | direct value text |
| data styles/colors | Yes | style controls |
| positive clock | Yes | Clock editor |
| negative clock | Yes | Clock editor |
| active-edge marker | Yes | Clock property |
| clock gating style | Yes | enable change points |
| period | Yes | property |
| phase / half-cycle | Yes | property |
| gap | Yes | Timeline Gap GUI |
| spacer | Yes | Add Spacer GUI |
| signal groups | Yes | arbitrary GUI groups |
| node | Yes | Semantic Anchor / Marker |
| edge | Yes | Transition Arrow GUI |
| edge label | Yes | direct text + drag |
| straight / curved / sharp / diagonal edge | Yes | line style |
| arrows / bidirectional / no arrow | Yes | arrow style |
| horizontal scale | Yes | zoom/time scale |
| header/footer | Yes | enhanced document layout |
| ticks / tocks | Yes | ruler controls |
| skin/render geometry | Yes | WaveDrom as Golden Reference |

## 3. Functions intentionally replaced by GUI/Semantic JSON

- `wave: "0...1..0"` -> `values[{start,value}]`
- `.` -> implicit continuation
- character-position `node` -> Signal Geometry Anchor
- textual `edge` -> Transition Arrow tool
- group array editing -> Signal Tree Drag & Drop
- `period/phase` source editing -> properties GUI
- `gap` character -> Insert Timeline Gap
- `hscale` source editing -> View/Time Scale UI

## 4. Geometry acceptance

At minimum create Golden SVG cases for:

- 0 -> 1
- 1 -> 0
- 0 -> X
- X -> 0
- 1 -> X
- X -> 1
- bus -> bus
- X -> bus
- bus -> X
- Z transitions
- positive clock
- negative clock
- gated clock
- phase 0.5
- gap

Visual-only human approval is insufficient; compare normalized SVG path geometry where practical.
