# GUI Specification

## 1. Main layout

- Top: Ribbon/Toolbar
- Left: Signal/Group tree
- Center: Waveform canvas
- Right: lightweight Inspector
- Bottom: context editor tabs
- Overlay: Legend and Annotations

## 2. Bottom tabs

Default tabs:

1. Signal
2. Annotation
3. Problems
4. JSON

JSONは低優先度。通常表示しない。ユーザーが明示的に開いた場合のみ表示する。

Selection follow:

- Signal selection -> Signal tab
- Annotation selection -> Annotation tab
- Pin / Follow Selection OFFで現在タブを固定可能

## 3. Signal editor

Event Table:

- Start
- Value
- optional display format/comment

User edits semantic change points. End/duration are calculated display values and canonical save dataにはしない。

Binary quick buttons: 0 / 1 / X / Z.
Bus editor supports hex/binary/symbol/X/Z.
Clock has dedicated generator form.

## 4. Annotation editor

- type
- from/to anchor
- label
- position
- start/end/label offsets in px
- snap state
- style

On-canvas editing:

- drag free movement
- arrow keys 1 px
- Shift+arrow 10 px
- handles for endpoints
- independent label movement

## 5. Group UI

Header buttons:

- + Group
- + Signal

Group menu:

- Rename
- Add Signal
- Insert Group Above/Below
- Duplicate
- Move Up/Down
- Collapse
- Delete

Drag & Drop reorders groups and signals. Moving a signal between groups never changes its role.

## 6. Legend

Legend is selectable overlay object.

- drag to move
- keyboard nudge
- X/Y inspector
- horizontal/vertical orientation
- show/hide
- show only used roles

## 7. AI-readable mockup requirements

The HTML mockup is a semantic reference for implementation agents.

- no canvas for UI structure
- semantic HTML controls
- stable `data-testid`
- `data-role`, `data-signal`, `data-anchor` attributes
- SVG only for waveform visual area
- tabs are real buttons
- controls have explicit labels
- source images retained under `assets/original/`
