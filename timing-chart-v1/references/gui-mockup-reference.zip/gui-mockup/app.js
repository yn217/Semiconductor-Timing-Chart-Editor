(() => {
  const tabs = [...document.querySelectorAll('.tab')];
  const panels = [...document.querySelectorAll('.tab-panel')];
  tabs.forEach(btn => btn.addEventListener('click', () => {
    tabs.forEach(x => x.classList.toggle('active', x === btn));
    panels.forEach(p => p.classList.toggle('active', p.id === `tab-${btn.dataset.tab}`));
  }));

  const legend = document.querySelector('.legend');
  let drag = null;
  legend.addEventListener('pointerdown', e => {
    if (e.button !== 0) return;
    const r = legend.getBoundingClientRect();
    const parent = legend.parentElement.getBoundingClientRect();
    drag = {dx:e.clientX-r.left, dy:e.clientY-r.top, parent};
    legend.setPointerCapture(e.pointerId);
  });
  legend.addEventListener('pointermove', e => {
    if (!drag) return;
    const x = Math.max(0, Math.min(drag.parent.width-legend.offsetWidth, e.clientX-drag.parent.left-drag.dx));
    const y = Math.max(0, Math.min(drag.parent.height-legend.offsetHeight, e.clientY-drag.parent.top-drag.dy));
    legend.style.left = `${x}px`; legend.style.top = `${y}px`; legend.style.right = 'auto';
  });
  legend.addEventListener('pointerup', e => { drag = null; legend.releasePointerCapture(e.pointerId); });
  legend.addEventListener('keydown', e => {
    if (!['ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(e.key)) return;
    e.preventDefault();
    const step = e.shiftKey ? 10 : 1;
    const parent = legend.parentElement.getBoundingClientRect();
    const r = legend.getBoundingClientRect();
    let x = r.left-parent.left, y = r.top-parent.top;
    if (e.key === 'ArrowLeft') x -= step;
    if (e.key === 'ArrowRight') x += step;
    if (e.key === 'ArrowUp') y -= step;
    if (e.key === 'ArrowDown') y += step;
    x = Math.max(0, Math.min(parent.width-legend.offsetWidth,x));
    y = Math.max(0, Math.min(parent.height-legend.offsetHeight,y));
    legend.style.left=`${x}px`; legend.style.top=`${y}px`; legend.style.right='auto';
  });
})();
