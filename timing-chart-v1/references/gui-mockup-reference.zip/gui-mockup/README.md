# GUI Mockup Reference

This directory exists so AI implementation/review agents can inspect GUI structure as HTML/CSS/JS instead of relying only on screenshots.

## Files

- `index.html` — semantic GUI structure and tab content
- `styles.css` — layout and visual reference
- `app.js` — tab switching + movable legend behavior
- `assets/original/gui-signal-tab.png` — generated visual reference
- `assets/original/gui-annotation-tab.png` — generated visual reference
- `assets/original/gui-json-tab.png` — generated visual reference

## Important

The SVG waveforms in `index.html` are only GUI layout placeholders. Production waveform geometry must follow the WaveDrom Golden Reference described in `docs/WAVEDROM_COMPATIBILITY.md`.
